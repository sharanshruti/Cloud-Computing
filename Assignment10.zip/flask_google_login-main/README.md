# Simple sample Flask App with Google Login

For documentation check out:
https://www.youtube.com/watch?v=FKgJEfrhU1E
